# Project: Feed Reader Testing(Feeds of Udacity)
 
## contents
	*css(icomoon.css,normalize.css,style.css)
	*fonts(icomoon.eot,icomoon.svg,icomoon.ttf,icomoon.woff)
	*jasmine(lib/jasmine-2.1.2/boot.js,console.js,jasmine-html,jasmine-css,jasmine-js,jasmine_favicon.png)
			(spec/feedreader.js)
	*js(app.js)
	*index.html

## What i learnt
	*I learned how to use Jasmine to write a number of tests against a pre-existing application. These will test the underlying business logic of the application as well as the event handling and DOM manipulation.

## Use i found
	*Testing is an important part of the development process and many organizations practice a standard of development known as "test-driven development". This is when developers write tests first, then started developing their application. Initially their tests get fail,so they started writing application code.
	Whether you work in an organization that uses test-driven development or in an organization that uses tests to make sure future feature development doesn't break existing features, it's an important skill to have!

## The way how i am going to use this in my career
	*Writing effective tests requires analyzing multiple aspects of an application including the HTML, CSS and JavaScript - an extremely important skill when changing teams or joining a new company.Good tests give you the ability to quickly analyze whether new code breaks an existing feature within your codebase, without having to manually test all of the functionality.

## Dependencies
	*As all the files are interlinked to each other.css files are used for styling the program.js files will useful
	for writing our code/program structure step by step.Mainly in this project we wrote specs by mentioning the suite names.

## what i got in this project
	*I wrote all the specs according to the commands given with a perfect structure, by observing all the js,css,html files.i wrote 7specs and i run with 0 failures.

## Instructions
	*In this i used mainly Jasmine plug-in.After finishing all the observation go to index.html.Check the options and open it in the websites like..(chrome,browser).The output will contain 7specs with 0failures.And in the top we can have the websites(addresses are mentioned in the app.js file).By choosing particular option we can enter in to that website and we can have the content(information) present in it. For references we can add websites in unlimited amount.

