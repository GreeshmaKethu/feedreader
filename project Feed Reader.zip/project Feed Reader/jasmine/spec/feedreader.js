$(function() {
    
    describe('RSS Feeds', function() {

        //test spec to check wheather all feed variables are defined and not empty
        it('are defined', function() {
            expect(allFeeds).toBeDefined();
            expect(allFeeds.length).not.toBe(0);
        });


        //test spec for all feed urls to be defined and are not empty
          it('url is defined and not empty',function(){

            for(let i=0;i<allFeeds.length;i++) {
                expect(allFeeds[i].url).toBeDefined();
                expect(allFeeds[i].url.length).not.toBe(0);
            }

        });
         //test spec for all feed names to be defined and are not empty
        it('name is defined and not empty',function(){

            for(let i=0;i<allFeeds.length;i++) {
                expect(allFeeds[i].name).toBeDefined();
                expect(allFeeds[i].name.length).not.toBe(0);
            }
            
        });
    });

        // test suite named "The menu"
        describe('The menu',function(){


        //test spect for ensuring the menu element to be hidden by default
        it('menu element is hidden',function(){
           expect($('body').hasClass('menu-hidden')).toBe(true); 
        });


        //test spec for ensuring the menu changing visibility when menu icon is clicked
        it('menu changes on clicking menu icon',function(){
            $('.menu-icon-link').trigger('click');
            expect($('body').hasClass('menu-hidden')).toBe(false); 
            $('.menu-icon-link').trigger('click');
            expect($('body').hasClass('menu-hidden')).toBe(true);
        });
    });


    //test suite named "Initial Entries"
    describe('Initial Entries',function() {

        //test for calling loadFeed function and ensuring that there is atleast one entry
        beforeEach(function(done) {
            loadFeed(0,done);
        });

        it('if entry has more than 0 entries',function(done){
            var entries =$('.entry');
            expect(entries.length).toBeGreaterThan(0);
            done();
        });
    });

    //test suite named "New Feed Selection"
    describe('New Feed Selection',function() {
               var prevFeedData;
               var newFeedData;

     beforeEach(function(done) {
       loadFeed(0, function() {
          // feed 0 done loading
       prevFeedData = $(".entry-link").html();
       loadFeed(1, function(){
      // feed 1 done loading
      newFeedData= $(".entry-link").html(); 
      // all variables initialized, can begin tests
      done();
    });
  });
});

      it('When a new feed is loaded by the loadFeed function the content changes', function(done) {
        // checks the new Url does not match the Url of the previous feed
        newFeedData = $(".entry-link").html();
        expect(newFeedData).not.toBe(prevFeedData);
        done();
      });
    });
  }());